
# India Crime Heatmap - Streamlit App

This repository contains a Streamlit app that:
- Loads district-wise crime data (CSV) from an uploaded ZIP or `data/crime_district.csv`.
- Downloads a district-level GeoJSON for India (or you can upload your own).
- Produces a choropleth (green=low, yellow=medium, red=high) showing crime intensity by district.
- Provides a sidebar input "Provide me info about the place you are in exactly" where the user can type an address or `lat,lon`.
- Geocodes the input, finds the district, and queries OpenStreetMap (Overpass) for nearby police stations.

To run locally:
1. Place your processed district crime CSV at `data/crime_district.csv` (columns: district, crime_count) OR upload the ZIP via the app.
2. Optionally add a GeoJSON at `data/INDIA_DISTRICTS.geojson`.
3. Install dependencies: `pip install -r requirements.txt`
4. Run: `streamlit run app.py`

Notes:
- GeoJSON source used by default: Datta07's INDIAN-SHAPEFILES repository.
- Overpass API is used for nearest police station lookup; it requires internet and may rate-limit.
- Some district name mismatches may require manual cleaning of district names.
